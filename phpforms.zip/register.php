<?php

require_once __DIR__ . "/functions.php";

session_start();

if($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['error'] = "Invalid Request Method";
    redirect("./index.php");
}
else {

    // echo "<pre>";
    // print_r($_POST);
    // echo "</pre>";

    // echo "<pre>";
    // print_r($_SERVER);
    // echo "</pre>";

    $fullName = validateInput($_POST['fullName']);
    $emailAddress = validateInput($_POST['email']);
    $password = trim($_POST['password']);
    $gender = $_POST['gender'];
    $phoneNumber = trim($_POST['phoneNumber']);
    $address = validateInput($_POST['address']);
    $placeOfBirth = validateInput($_POST['placeOfBirth']);
    $dateOfBirth = trim($_POST['dateOfBirth']);


    echo $fullName;

}




