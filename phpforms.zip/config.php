<?php

return [
  "hostname" => "localhost",
  "username" => "root",
  "password" => "",
  "database" => "phpforms" 
]; 